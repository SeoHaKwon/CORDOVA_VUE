<template>
  <AskPage></AskPage>
</template>

<script>
// @ is an alias to /src
import AskPage from '@/components/AppJoin/AskPage'
export default {
  name: 'Ask',
  components: {
    AskPage
  }
}
</script>
