<template>
  <FirstPage></FirstPage>
</template>

<script>
// @ is an alias to /src
import FirstPage from '@/components/AppJoin/FirstPage.vue'
export default {
  name: 'firststep',
  components: {
    FirstPage
  }
}
</script>
