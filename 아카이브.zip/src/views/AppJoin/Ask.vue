<template>
  <AskPage2></AskPage2>
</template>

<script>
// @ is an alias to /src
import AskPage2 from '@/components/AppJoin/AskPage2.vue'
export default {
  name: 'Ask',
  components: {
    AskPage2
  }
}
</script>
