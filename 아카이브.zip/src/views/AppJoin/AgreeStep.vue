<template>
  <AgreePage></AgreePage>
</template>

<script>
// @ is an alias to /src
import AgreePage from '@/components/AppJoin/AgreePage'
export default {
  name: 'agreePage',
  components: {
    AgreePage
  }
}
</script>
