<template>
  <Additional></Additional>
</template>

<script>
// @ is an alias to /src
import Additional from '@/components/AppJoin/Additional.vue'
export default {
  name: 'additional',
  components: {
    Additional
  }
}
</script>
